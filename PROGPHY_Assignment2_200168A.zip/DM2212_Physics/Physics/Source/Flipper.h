#pragma once
#include "GameObject.h"

class Flipper : public GameObject
{
	double cooldown;


};

